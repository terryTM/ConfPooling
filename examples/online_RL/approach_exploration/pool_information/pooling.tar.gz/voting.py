import json
import random
import pandas as pd
from pathlib import Path
from collections import defaultdict, Counter
import re
import numpy as np
import argparse

# ===== 工具函数 ====
import ast
# ===== online screening ======

def load_traces(file_path):
    traces = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                try:
                    traces.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return traces

def clean_latex_answer(ans: str) -> str:
    """清洗 LaTeX 表达式：去空格、去 a= 等、标准化 \\dfrac"""
    """只有pooling_information中提取followup和base_answer时使用，traces中的answer已经给定，是cleaned的"""
    """最理想的是统一适用data_creation中的extract函数"""
    if not ans:
        return ans

    # 去掉 LaTeX 空格命令（\ , \quad, \qquad 等）
    ans = re.sub(r"\\(?:,|;|:|!|quad|qquad|enspace|,| )", "", ans)
    
    # 去掉所有普通空格
    ans = re.sub(r"\s+", "", ans)
    
    # 将 \dfrac 转为 \frac
    ans = ans.replace(r"\dfrac", r"\frac")
    
    # 去掉形如 a=、x=、y= 等赋值
    ans = re.sub(r"\b[a-zA-Z]\s*=", "", ans)
    
    # 去掉可能的多余逗号空位，比如 "2,,3" → "2,3"
    ans = re.sub(r",+", ",", ans)
    
    # 去掉首尾逗号
    ans = ans.strip(",")
    
    return ans
def extract_boxed_answer(text: str):
    """提取文本中最后一个 \\boxed{...} 的内容（支持任意嵌套 {}）并清洗"""
    if not text:
        return None

    results = []
    pos = 0
    while True:
        start = text.find(r'\boxed{', pos)
        if start == -1:
            break  # 没有更多了

        i = start + len(r'\boxed{')
        depth = 1
        content_chars = []

        while i < len(text) and depth > 0:
            ch = text[i]
            if ch == '{':
                depth += 1
                content_chars.append(ch)
            elif ch == '}':
                depth -= 1
                if depth > 0:
                    content_chars.append(ch)
            else:
                content_chars.append(ch)
            i += 1

        if depth == 0:
            results.append(''.join(content_chars))
            pos = i  # 从上次结束后继续查找
        else:
            break  # 不完整，结束循环

    if not results:
        return None

    # 返回最后一个
    return clean_latex_answer(results[-1])
def data_loading(base_dir, dataname, is_followup=False):
    results = defaultdict(list)
    for jsonl_path in base_dir.glob(f"{dataname}_*.jsonl"):
        qid_match = re.search(rf"{dataname}_(\d+)_", jsonl_path.name)
        if not qid_match:
            continue
        qid = int(qid_match.group(1))
        traces = load_traces(jsonl_path)
        if is_followup:
            for item in traces:
                base_ans = clean_latex_answer(item.get("base_answer"))
                ans = extract_boxed_answer(item.get("trace_2", "")) 
                conf = np.min(item.get("group_confidences_2", np.nan))
                if ans:
                    results[qid].append((base_ans, ans, conf))
        else:
            for item in traces:
                ans = clean_latex_answer(item.get("answer"))
                # 算一个trace level的confidence
                conf = item.get("group_confidence", [])
                if ans:
                    results[qid].append((ans, conf))
    return results
def load_ground_truth(path):
    gt = {}
    for i, item in enumerate(load_traces(path)):
        gt[i] = str(item.get("answer", "")).strip()
    return gt
## voting 

def online_voting(traces, num_calibration=16, use_small_threshold=False, consensus_tau=0.95):
   # True: 10% percentile (lenient), False: 90% percentile (strict)
    random.seed(13)
    voting_results = {}
    for qid, ans_list in traces.items():
        # traces: list of dict, each dict has keys: 'answer', 'is_correct', 'group_confidence' (list of float)
        # --- Calculate Threshold ---
        s = None
        if len(ans_list) >= num_calibration:
            # TODO 样本不太够才这样做，应该多添加一些样本，跟文章一样把offline的池子换成4096个的，这样就可以resample了
            # TODO 还要多跑一些方法
            # TODO 还要多跑一些数据集
            # split ans_list into calibration and voting sets
            calibration_traces = random.sample(ans_list, num_calibration)
            
            lowest_confs = [min(t[1]) for t in calibration_traces if t[1]]
            eta = 10 if use_small_threshold else 90
            if lowest_confs:
                # s_high = np.percentile(lowest_confs, 10)
                # s_low = np.percentile(lowest_confs, 90) # 这个更大
                s = np.percentile(lowest_confs, eta)
            # filtered_calibration_traces = [t for t in calibration_traces if min(t[1]) >= s]
            other_traces = [t for t in ans_list if t not in calibration_traces]
        if s is not None:
            # predicted_good = calibration_traces  # ✅ 收集未被截断的 trace
            
            totals = defaultdict(float)
            true_totals = defaultdict(float)
            for ans, conf in calibration_traces:
                totals[ans] += conf
                if conf >= s:
                    true_totals[ans] += conf
            for trace in other_traces:
                # 2. 找到 confidence 总和最大的 answer
                best_answer = max(totals, key=totals.get)
                best_conf = totals[best_answer]

                # 3. 计算占总和百分比
                total_conf_all = sum(totals.values())
                current_consensus = best_conf / total_conf_all
                # ✅ 提前停止
                if current_consensus >= consensus_tau:
                    break
                conf_curve = trace[1]
                stop_indices = np.where(np.array(conf_curve) < s)[0] if conf_curve else []
                predicted_as_bad = len(stop_indices) > 0

                # ✅ 保存分类结果
                if predicted_as_bad:
                    continue
                else:
                    # predicted_good.append(trace)
                    totals[trace[0]] += trace[1]
                    true_totals[trace[0]] += trace[1]
        true_best_answer = max(true_totals, key=true_totals.get) if true_totals else None
        voting_results[qid] = true_best_answer
    return voting_results, s
# ===== 主函数 =====
def main():
    parser = argparse.ArgumentParser(description="Generate trace dataset with full precision confidence.")
    parser.add_argument("--dataname", type=str, required=True)
    parser.add_argument("--version", type=str, required=True)
    parser.add_argument("--ifcnt", type=str, default="False")
    args = parser.parse_args()
    print(f"dataname: {args.dataname}, version: {args.version}, ifcnt: {args.ifcnt}")
    # ===== 路径配置 =====
    POOLING_DATA_DIR = Path(f"/home/yz54720/Projects/Method/deepconf/data/processed/{args.dataname}/pool_information_v{args.version}")
    TRACES_DIR = Path(f"/home/yz54720/Projects/Method/deepconf/data/processed/{args.dataname}/traces")
    DATA_PATH = Path(f"/home/yz54720/Projects/Method/deepconf/data/raw/{args.dataname}.jsonl")
    OUTPUT_PATH = POOLING_DATA_DIR / "question_level_voting_summary.csv"
    TAU = 0.95
    gt = load_ground_truth(DATA_PATH)
    # loading traces
    # traces_data = data_loading(TRACES_DIR, args.dataname, is_followup=False)
    raw_traces = data_loading(TRACES_DIR, args.dataname, is_followup=False)
    # loading followup results
    followup_data = data_loading(POOLING_DATA_DIR, args.dataname, is_followup=True)
    # voting by qid
    baseline_correct_cnt = 0
    followup_correct_cnt = 0
    majority_correct_cnt = 0
    # baseline voting
    baseline_voted_answers, conf_bar = online_voting(raw_traces, num_calibration=16, use_small_threshold=False, consensus_tau=TAU)
    # online screening 就是把切一刀
    # 但是pooling information他们没用consensus
    # 后面要改成用consensus的
    for qid in gt.keys():
        ground_truth = gt[qid]
        followups = followup_data.get(qid, [])
    
        # majority voting
        majority_count = {}
        for ans, conf in raw_traces.get(qid, []):
            majority_count[ans] = majority_count.get(ans, 0) + 1
        # voting result
        
        if majority_count:
            majority_voted_answer = max(majority_count, key=majority_count.get)
        else:
            majority_voted_answer = None
        if majority_voted_answer == ground_truth:
            majority_correct_cnt += 1
        # count answers
        counts = Counter([ans for ans, _ in traces])
        top_counts_sorted = sorted(set(counts.values()), reverse=True)
        threshold_values = top_counts_sorted[:min(5, len(top_counts_sorted))]
        top5_anc = {ans: cnt for ans, cnt in counts.items() if cnt in threshold_values}

        # followup voting
        followup_score_c = {}
        if gt[qid] not in [base_ans for base_ans, _, _ in followups]:
            print(f"⚠️ QID {qid}: ground truth {gt[qid]!r} not in follow-up base answers.")
        for base_ans, ans, conf in followups:
            if base_ans in top5_anc:
                cnt = top5_anc[base_ans]
            else: 
                cnt = 1
                print(f"⚠️ QID {qid}: follow-up base answer {base_ans!r} not in top5 of traces.")
            # followup_score_c[ans] = followup_score_c.get(ans, 0) + conf * (cnt if args.ifcnt == "True" else 1)
            followup_score_c[ans] = followup_score_c.get(ans, 0) + conf
        # voting result
        if followup_score_c:
            voted_answer = max(followup_score_c, key=followup_score_c.get)
        else:
            voted_answer = None
        if voted_answer == ground_truth:
            followup_correct_cnt += 1
        if (baseline_voted_answer != ground_truth) or (voted_answer != ground_truth):
            print(f"❌ QID {qid}: GT={ground_truth!r}, Baseline Vote={baseline_voted_answer!r}, Follow-up Vote={voted_answer!r}")
            # details
            for base_ans, ans, conf in followups:
                print(f"    Base Ans: {base_ans!r}, Follow-up Ans: {ans!r}, Conf: {conf:.4f}, Weight: {top5_anc.get(base_ans, 1)}")
            print(f"followup_score_c: {followup_score_c}")
    total_questions = len(gt)
    print(f"Baseline Accuracy: {baseline_correct_cnt}/{total_questions} = {baseline_correct_cnt/total_questions:.4f}")
    print(f"Majority Accuracy: {majority_correct_cnt}/{total_questions} = {majority_correct_cnt/total_questions:.4f}")
    print(f"Follow-up Accuracy: {followup_correct_cnt}/{total_questions} = {followup_correct_cnt/total_questions:.4f}")

if __name__ == "__main__":
    main()
